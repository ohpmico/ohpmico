SVG node.js badges for scoped packages as well!
> This is an extension of [ohpm.openharmony.cn].

<br>


### TODO

[ohpm.openharmony.cn]: https://ohpm.openharmony.cn/